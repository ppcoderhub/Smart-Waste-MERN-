# Pickup Status Workflow Fix

The pickup status flow is now:

**Pending → Scheduled → Collected → Completed**

A pending pickup can also be **Cancelled** by the citizen.

## Where it works
- Dashboard: All / Pending / Scheduled / Collected / Completed / Cancelled filters and live counts.
- History: all six status filters and search.
- Collector/Admin: Accept pending, Mark collected scheduled pickups, Mark completed collected pickups.
- Completed pickups award points once and count toward impact statistics.
- Collector route keeps collected pickups visible until they are completed.

## Run
### Server
```powershell
cd server
npm install
npm run dev
```

### Client
```powershell
cd client
npm install
npm run dev
```

If an old MongoDB database is used, existing documents with pending/scheduled/collected/cancelled continue to work. New completed status is supported automatically by the updated schema.
