// Nearest-neighbour route ordering: a simple heuristic for the travelling-salesman problem.
const dist = (a, b) => Math.hypot(a.lat - b.lat, a.lng - b.lng);
export function optimiseRoute(pickups, start) {
  const left = [...pickups];
  const ordered = [];
  let cur = start || left[0]?.location;
  while (left.length) {
    let bi = 0;
    left.forEach((p, i) => { if (dist(cur, p.location) < dist(cur, left[bi].location)) bi = i; });
    const [next] = left.splice(bi, 1);
    ordered.push(next);
    cur = next.location;
  }
  return ordered;
}
