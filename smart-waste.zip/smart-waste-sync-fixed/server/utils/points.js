// Eco-points: recyclable waste earns 3x more per kg than non-recyclable waste.
export const RECYCLABLE = new Set(['organic', 'plastic', 'paper', 'glass', 'metal', 'e-waste']);
export const pointsFor = (pickup) =>
  Math.max(1, Math.round(pickup.quantityKg * (RECYCLABLE.has(pickup.wasteType) ? 15 : 5)));
