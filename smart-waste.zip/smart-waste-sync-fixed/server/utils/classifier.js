const RULES = {
  plastic: ['bottle', 'plastic', 'bag', 'wrapper', 'container'],
  paper: ['paper', 'cardboard', 'newspaper', 'box', 'carton'],
  glass: ['glass', 'jar'],
  metal: ['can', 'tin', 'metal', 'foil', 'aluminium'],
  organic: ['food', 'peel', 'fruit', 'vegetable', 'leaf', 'tea', 'coffee'],
  'e-waste': ['battery', 'phone', 'charger', 'laptop', 'cable', 'bulb'],
  hazardous: ['paint', 'chemical', 'medicine', 'syringe', 'pesticide'],
};
const INFO = {
  plastic: ['Rinse and dry, then put in the dry-recycling bin.', true],
  paper: ['Keep it dry and flatten boxes before recycling.', true],
  glass: ['Rinse and place in the glass bin. Do not mix with ceramics.', true],
  metal: ['Rinse cans and place in the dry-recycling bin.', true],
  organic: ['Use the wet-waste bin or compost it at home.', true],
  'e-waste': ['Hand over at an e-waste collection point. Never bin it.', true],
  hazardous: ['Store sealed and book a hazardous pickup. Never mix with other waste.', false],
  general: ['Put in the general waste bin.', false],
};
export const build = (category, confidence = 0.6, item = '') => {
  const c = INFO[category] ? category : 'general';
  return { item, category: c, confidence, tip: INFO[c][0], recyclable: INFO[c][1] };
};

export function classifyText(label = '') {
  const t = label.toLowerCase();
  const hit = Object.entries(RULES).find(([, words]) => words.some((w) => t.includes(w)));
  return build(hit ? hit[0] : 'general', hit ? 0.7 : 0.3, label);
}

export async function classifyImage(buffer, mime) {
  if (!process.env.ANTHROPIC_API_KEY)
    throw Object.assign(new Error('Photo AI is off. Add ANTHROPIC_API_KEY on the server, or type the item name instead.'), { status: 503 });
  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'x-api-key': process.env.ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01' },
    body: JSON.stringify({
      model: process.env.ANTHROPIC_MODEL || 'claude-sonnet-5-5', max_tokens: 300,
      messages: [{ role: 'user', content: [
        { type: 'image', source: { type: 'base64', media_type: mime, data: buffer.toString('base64') } },
        { type: 'text', text: 'Identify the main waste item. Reply with JSON only: {"item":"...","category":"organic|plastic|paper|glass|metal|e-waste|hazardous|general","confidence":0-1}' },
      ] }],
    }),
  });
  if (!res.ok) throw new Error('The AI service could not read this image.');
  const data = await res.json();
  const j = JSON.parse(data.content[0].text.replace(/```json|```/g, '').trim());
  return build(j.category, j.confidence, j.item);
}
