import mongoose from 'mongoose';
export const WASTE_TYPES = ['organic', 'plastic', 'paper', 'glass', 'metal', 'e-waste', 'hazardous', 'general'];
export default mongoose.model('Pickup', new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  wasteType: { type: String, enum: WASTE_TYPES, required: true },
  quantityKg: { type: Number, default: 1, min: 0.1 },
  address: { type: String, required: true },
  location: { lat: { type: Number, required: true }, lng: { type: Number, required: true } },
  date: { type: Date, required: true },
  pointsAwarded: { type: Boolean, default: false },
  status: { type: String, enum: ['pending', 'scheduled', 'collected', 'completed', 'cancelled'], default: 'pending' },
}, { timestamps: true }));
