import mongoose from 'mongoose';
export default mongoose.model('User', new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true, lowercase: true },
  password: { type: String, required: true },
  points: { type: Number, default: 0 },
  role: { type: String, enum: ['citizen', 'collector', 'admin'], default: 'citizen' },
}, { timestamps: true }));
