import 'dotenv/config';
import express from 'express';
import 'express-async-errors'; // async route errors reach the error handler instead of crashing Node
import cors from 'cors';
import mongoose from 'mongoose';
import auth from './routes/auth.js';
import pickups from './routes/pickups.js';
import classify from './routes/classify.js';
import stats from './routes/stats.js';
import users from './routes/users.js';
import assistant from './routes/assistant.js';

const app = express();
app.use(cors({ origin: process.env.CLIENT_URL }));
app.use(express.json());
app.use('/api/auth', auth);
app.use('/api/pickups', pickups);
app.use('/api/classify', classify);
app.use('/api/stats', stats);
app.use('/api/users', users);
app.use('/api/assistant', assistant);
app.use((err, _req, res, _next) => res.status(err.status || 500).json({ message: err.message }));

mongoose.connect(process.env.MONGO_URI).then(() => {
  app.listen(process.env.PORT || 5000, () => console.log('API running'));
}).catch((e) => { console.error(e); process.exit(1); });
