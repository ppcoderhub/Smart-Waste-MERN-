import { Router } from 'express';
import multer from 'multer';
import { protect } from '../middleware/auth.js';
import { classifyImage, classifyText } from '../utils/classifier.js';

const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 5 * 1024 * 1024 } });
const r = Router();
r.post('/', protect, upload.single('image'), async (req, res, next) => {
  try {
    if (req.file) return res.json(await classifyImage(req.file.buffer, req.file.mimetype));
    if (req.body.label) return res.json(classifyText(req.body.label));
    res.status(400).json({ message: 'Upload a photo or type the item name.' });
  } catch (e) { next(e); }
});
export default r;
