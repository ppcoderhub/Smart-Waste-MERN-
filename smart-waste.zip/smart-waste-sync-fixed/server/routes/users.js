import { Router } from 'express';
import User from '../models/User.js';
import { protect } from '../middleware/auth.js';

const r = Router();
r.use(protect);
r.get('/me', async (req, res) => {
  const u = await User.findById(req.user.id).select('name role points');
  if (!u) return res.status(404).json({ message: 'User not found.' });
  const rank = (await User.countDocuments({ role: 'citizen', points: { $gt: u.points } })) + 1;
  res.json({ name: u.name, role: u.role, points: u.points, rank });
});
r.get('/leaderboard', async (_req, res) => {
  res.json(await User.find({ role: 'citizen', points: { $gt: 0 } }).sort('-points').limit(5).select('name points'));
});
export default r;
