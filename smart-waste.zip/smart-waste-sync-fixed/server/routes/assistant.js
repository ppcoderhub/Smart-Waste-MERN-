import { Router } from 'express';
import { protect } from '../middleware/auth.js';
import { classifyText } from '../utils/classifier.js';

const SYSTEM = `You are EcoBot, a friendly waste-sorting and recycling assistant inside the Smart Waste app.
Answer in under 80 words, in plain language. Say which bin an item goes in, how to prepare it, and when to book a pickup or use an e-waste/hazardous drop-off.
Politely decline topics unrelated to waste, recycling, composting or the environment.`;

const r = Router();
r.post('/', protect, async (req, res, next) => {
  try {
    let msgs = (Array.isArray(req.body.messages) ? req.body.messages : [])
      .filter((m) => ['user', 'assistant'].includes(m?.role) && typeof m.content === 'string' && m.content.trim())
      .map((m) => ({ role: m.role, content: m.content.slice(0, 1000) }))
      .slice(-10);
    while (msgs.length && msgs[0].role !== 'user') msgs.shift(); // API requires a user turn first
    if (!msgs.length || msgs[msgs.length - 1].role !== 'user') return res.status(400).json({ message: 'Ask a question first.' });

    if (!process.env.ANTHROPIC_API_KEY) {
      const c = classifyText(msgs[msgs.length - 1].content);
      return res.json({ offline: true, reply: `(Offline mode) That looks like ${c.category} waste. ${c.tip}` });
    }
    const api = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-api-key': process.env.ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01' },
      body: JSON.stringify({ model: process.env.ANTHROPIC_MODEL || 'claude-sonnet-5-5', max_tokens: 300, system: SYSTEM, messages: msgs }),
    });
    if (!api.ok) throw Object.assign(new Error('EcoBot is unavailable right now. Try again shortly.'), { status: 502 });
    const data = await api.json();
    res.json({ reply: data.content?.map((c) => c.text || '').join('').trim() });
  } catch (e) { next(e); }
});
export default r;
