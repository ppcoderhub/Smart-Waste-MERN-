import { Router } from 'express';
import Pickup from '../models/Pickup.js';
import { protect, allow } from '../middleware/auth.js';

const r = Router();
r.get('/', protect, allow('admin'), async (_req, res) => {
  const since = new Date(Date.now() - 6 * 864e5);
  since.setHours(0, 0, 0, 0);
  const [byType, byStatus, daily] = await Promise.all([
    Pickup.aggregate([{ $match: { status: { $in: ['collected', 'completed'] } } }, { $group: { _id: '$wasteType', kg: { $sum: '$quantityKg' }, count: { $sum: 1 } } }]),
    Pickup.aggregate([{ $group: { _id: '$status', count: { $sum: 1 } } }]),
    Pickup.aggregate([
      { $match: { createdAt: { $gte: since } } },
      { $group: { _id: { $dateToString: { format: '%Y-%m-%d', date: '$createdAt' } }, count: { $sum: 1 } } },
    ]),
  ]);
  res.json({ byType, byStatus, daily });
});
export default r;
