import { Router } from 'express';
import Pickup from '../models/Pickup.js';
import User from '../models/User.js';
import { protect, allow } from '../middleware/auth.js';
import { optimiseRoute } from '../utils/route.js';
import { pointsFor } from '../utils/points.js';

const r = Router();
r.use(protect);
const staff = ['collector', 'admin'];

r.post('/', async (req, res) => {
  try {
    const { wasteType, quantityKg, address, location, date } = req.body;
    res.status(201).json(await Pickup.create({ wasteType, quantityKg, address, location, date, user: req.user.id, status: 'scheduled' }));
  } catch (e) { res.status(400).json({ message: 'Fill in every field, including a valid location.' }); }
});
r.get('/', async (req, res) => {
  const q = staff.includes(req.user.role) ? {} : { user: req.user.id };
  res.json(await Pickup.find(q).populate('user', 'name').sort('-createdAt'));
});
// declared before /:id routes. Optional ?lat=&lng= makes the route start from the collector's position.
r.get('/route', allow(...staff), async (req, res) => {
  const open = await Pickup.find({ status: { $in: ['pending', 'scheduled', 'collected', 'completed'] } }).populate('user', 'name').lean();
  const lat = parseFloat(req.query.lat), lng = parseFloat(req.query.lng);
  res.json(optimiseRoute(open, Number.isFinite(lat) && Number.isFinite(lng) ? { lat, lng } : undefined));
});
r.patch('/:id/status', allow(...staff), async (req, res) => {
  const { status } = req.body;
  if (!['pending', 'scheduled', 'collected', 'completed'].includes(status)) return res.status(400).json({ message: 'Invalid status.' });
  const p = await Pickup.findById(req.params.id).populate('user', 'name');
  if (!p) return res.status(404).json({ message: 'Pickup not found.' });
  if (p.status === 'cancelled') return res.status(400).json({ message: 'This pickup was cancelled by the citizen.' });
  const allowed = { pending: ['scheduled', 'cancelled'], scheduled: ['collected'], collected: ['completed'] };
  if (!allowed[p.status]?.includes(status)) return res.status(400).json({ message: `Cannot change ${p.status} to ${status}.` });
  p.status = status;
  let awarded = 0;
  if (status === 'completed' && !p.pointsAwarded) {
    awarded = pointsFor(p);
    p.pointsAwarded = true; // never award twice for the same pickup
    await User.findByIdAndUpdate(p.user._id, { $inc: { points: awarded } });
  }
  await p.save();
  res.json({ ...p.toObject(), awarded });
});
// Citizens can cancel their own pickup until a collector accepts it
r.patch('/:id/cancel', async (req, res) => {
  const p = await Pickup.findOne({ _id: req.params.id, user: req.user.id });
  if (!p) return res.status(404).json({ message: 'Pickup not found.' });
  if (p.status !== 'pending') return res.status(400).json({ message: 'Only pending pickups can be cancelled.' });
  p.status = 'cancelled';
  await p.save();
  res.json(p);
});
export default r;
