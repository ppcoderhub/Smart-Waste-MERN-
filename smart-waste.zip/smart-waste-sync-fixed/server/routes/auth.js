import { Router } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import User from '../models/User.js';

const r = Router();
const sign = (u) => jwt.sign({ id: u._id, role: u.role, name: u.name }, process.env.JWT_SECRET, { expiresIn: '7d' });

r.post('/register', async (req, res) => {
  const { name, email, password, role } = req.body;
  if (!name || !email || !password) return res.status(400).json({ message: 'Name, email and password are required.' });
  if (await User.findOne({ email })) return res.status(409).json({ message: 'That email is already registered.' });
  // Anyone can register as citizen or collector, but only the very first admin can be self-created.
  let safeRole = ['citizen', 'collector', 'admin'].includes(role) ? role : 'citizen';
  if (safeRole === 'admin' && (await User.exists({ role: 'admin' }))) safeRole = 'citizen';
  const u = await User.create({ name, email, password: await bcrypt.hash(password, 10), role: safeRole });
  res.status(201).json({ token: sign(u), user: { name: u.name, role: u.role }, downgraded: safeRole !== role && role === 'admin' });
});

r.post('/login', async (req, res) => {
  const u = await User.findOne({ email: req.body.email });
  if (!u || !(await bcrypt.compare(req.body.password || '', u.password)))
    return res.status(401).json({ message: 'Email or password is incorrect.' });
  res.json({ token: sign(u), user: { name: u.name, role: u.role } });
});
export default r;
