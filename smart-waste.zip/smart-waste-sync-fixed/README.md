# Smart Waste – Interactive Upgraded Edition

A React + Vite + Express + MongoDB waste collection platform.

## Main navigation
Dashboard • Schedule • Sort Waste • History • Impact • Rewards • Profile
Collectors/Admins also get Collector/Admin route management.

## Added interactive features
- Modern responsive navigation with active tabs and mobile bottom navigation
- Dashboard hero with live pickup refresh and quick actions
- Pickup history with search + status filters + timeline UI
- Environmental Impact dashboard with waste breakdown and CO₂ estimate
- Rewards, badges, points, challenges and leaderboard
- Profile page with theme selector and secure logout
- Existing waste classifier, photo drop area and EcoBot assistant
- Existing map picker, GPS location, pickup scheduling and collector route map
- Existing collector/admin statistics and route optimisation
- Automatic dashboard refresh every 15 seconds
- Toast notifications for pickup status changes
- Dark/light/system theme support

## Run
### Server
cd server
npm install
copy .env.example .env
# Set MONGO_URI, PORT=5000 and CLIENT_URL=http://localhost:5173
npm run dev

### Client
cd client
npm install
npm run dev

Open http://localhost:5173

MongoDB must be running. The project intentionally does not include node_modules.


### Completed status workflow
Collector flow: Scheduled → Collected → Completed. New customer bookings are created as Scheduled automatically; collectors then move them to Collected and Completed. Completed pickups remain visible in the collector route/history, earn points once, and count toward environmental impact.
