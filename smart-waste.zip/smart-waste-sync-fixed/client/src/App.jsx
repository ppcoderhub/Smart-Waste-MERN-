import { useEffect,useState } from 'react';
import { Routes,Route,Navigate,NavLink,useNavigate,useLocation } from 'react-router-dom';
import Login from './pages/Login.jsx'; import Dashboard from './pages/Dashboard.jsx'; import Schedule from './pages/Schedule.jsx'; import Classify from './pages/Classify.jsx'; import Staff from './pages/Staff.jsx'; import History from './pages/History.jsx'; import Rewards from './pages/Rewards.jsx'; import Impact from './pages/Impact.jsx'; import Profile from './pages/Profile.jsx'; import EcoBot from './components/EcoBot.jsx';

const links=[['/','⌂','Dashboard'],['/schedule','＋','Schedule'],['/classify','♻','Sort Waste'],['/history','◷','History'],['/impact','🌍','Impact'],['/rewards','🏆','Rewards']];
export default function App(){
 const [user,setUser]=useState(()=>JSON.parse(localStorage.getItem('user')||'null')); const nav=useNavigate(); const loc=useLocation();
 const [theme,setTheme]=useState(()=>localStorage.getItem('theme')||'');
 useEffect(()=>{if(theme)document.documentElement.setAttribute('data-theme',theme);else document.documentElement.removeAttribute('data-theme')},[theme]);
 const flip=()=>{const dark=theme?theme==='dark':matchMedia('(prefers-color-scheme: dark)').matches;const next=dark?'light':'dark';localStorage.setItem('theme',next);setTheme(next)};
 const onAuth=({token,user})=>{localStorage.setItem('token',token);localStorage.setItem('user',JSON.stringify(user));setUser(user);nav('/')};
 const logout=()=>{localStorage.clear();setUser(null);nav('/login')};
 if(!user)return <Routes><Route path="*" element={<Login onAuth={onAuth}/>} /></Routes>;
 const staff=user.role!=='citizen';
 return <><header className="appbar"><div className="brand-wrap"><div className="brand-mark">♻</div><div><strong className="brand">Smart Waste</strong><small>Smart recycling platform</small></div></div>
 <nav className="main-nav">{links.map(([to,ic,label])=><NavLink key={to} to={to} end={to==='/' } className={({isActive})=>isActive?'active':''}><span>{ic}</span>{label}</NavLink>)}{staff&&<NavLink to="/staff"><span>🚛</span>{user.role==='admin'?'Admin':'Collector'}</NavLink>}<NavLink to="/profile"><span>👤</span>Profile</NavLink></nav>
 <div className="nav-actions"><button className="icon-btn" onClick={flip} title="Toggle theme">🌓</button><button className="user-pill" onClick={()=>nav('/profile')}><span className="mini-avatar">{(user.name||'U')[0]}</span>{user.name}</button></div></header>
 <div className="mobile-nav">{links.slice(0,4).map(([to,ic,label])=><NavLink key={to} to={to} end={to==='/' }><span>{ic}</span><small>{label}</small></NavLink>)}</div>
 <main className="page"><Routes><Route path="/" element={<Dashboard/>}/><Route path="/schedule" element={<Schedule/>}/><Route path="/classify" element={<Classify/>}/><Route path="/history" element={<History/>}/><Route path="/impact" element={<Impact/>}/><Route path="/rewards" element={<Rewards/>}/><Route path="/profile" element={<Profile user={user} onLogout={logout}/>}/><Route path="/staff" element={staff?<Staff role={user.role}/>:<Navigate to="/"/>}/><Route path="*" element={<Navigate to="/"/>}/></Routes></main><EcoBot/></>
}
