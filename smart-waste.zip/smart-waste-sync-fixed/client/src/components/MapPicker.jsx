import { useEffect, useRef } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

const pin = (emoji) => L.divIcon({ html: `<div class="pin">${emoji}</div>`, className: '', iconSize: [34, 34], iconAnchor: [17, 34] });
const DEFAULT = [13.0827, 80.2707]; // Chennai, until the user picks a spot

/** Click the map or drag the pin to choose the pickup point. */
export default function MapPicker({ position, onChange }) {
  const el = useRef(null);
  const map = useRef(null);
  const marker = useRef(null);
  const cb = useRef(onChange);
  cb.current = onChange;

  useEffect(() => {
    map.current = L.map(el.current).setView(position ? [position.lat, position.lng] : DEFAULT, position ? 16 : 12);
    L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19, attribution: '© OpenStreetMap contributors' }).addTo(map.current);
    const place = (ll) => {
      if (!marker.current) {
        marker.current = L.marker(ll, { icon: pin('📍'), draggable: true }).addTo(map.current);
        marker.current.on('dragend', () => cb.current(marker.current.getLatLng()));
      } else marker.current.setLatLng(ll);
    };
    map.current.on('click', (e) => { place(e.latlng); cb.current(e.latlng); });
    if (position) place(position);
    map.current._place = place;
    return () => map.current.remove();
  }, []);

  // Position changed from outside (e.g. "Use my location")
  useEffect(() => {
    if (!position || !map.current) return;
    const cur = marker.current?.getLatLng();
    if (!cur || Math.abs(cur.lat - position.lat) > 1e-6 || Math.abs(cur.lng - position.lng) > 1e-6) {
      map.current._place(position);
      map.current.setView([position.lat, position.lng], Math.max(map.current.getZoom(), 16));
    }
  }, [position?.lat, position?.lng]);

  return <div ref={el} className="map" />;
}
