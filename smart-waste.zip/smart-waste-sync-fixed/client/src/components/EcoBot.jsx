import { useEffect, useRef, useState } from 'react';
import api, { errMsg } from '../api.js';

const HINTS = ['Can I recycle pizza boxes?', 'Where do old batteries go?', 'How do I start composting?'];

/** Floating assistant: ask anything about sorting, recycling or composting. */
export default function EcoBot() {
  const [open, setOpen] = useState(false);
  const [msgs, setMsgs] = useState([{ role: 'assistant', content: "Hi! I'm EcoBot ♻️ Ask me where any item should go." }]);
  const [text, setText] = useState('');
  const [busy, setBusy] = useState(false);
  const end = useRef(null);
  useEffect(() => { end.current?.scrollIntoView({ behavior: 'smooth' }); }, [msgs, open]);

  const send = async (q = text) => {
    q = q.trim();
    if (!q || busy) return;
    const next = [...msgs, { role: 'user', content: q }];
    setMsgs(next); setText(''); setBusy(true);
    try {
      const { data } = await api.post('/assistant', { messages: next });
      setMsgs([...next, { role: 'assistant', content: data.reply || 'Sorry, I have no answer for that.' }]);
    } catch (e) {
      setMsgs([...next, { role: 'assistant', content: errMsg(e) }]);
    } finally { setBusy(false); }
  };

  return (
    <>
      <button className="bot-fab" onClick={() => setOpen(!open)} aria-label="Open EcoBot assistant">{open ? '✕' : '💬'}</button>
      {open && (
        <div className="bot card" role="dialog" aria-label="EcoBot">
          <strong>EcoBot</strong>
          <div className="bot-log">
            {msgs.map((m, i) => <div key={i} className={`bubble ${m.role}`}>{m.content}</div>)}
            {busy && <div className="bubble assistant">Thinking…</div>}
            <div ref={end} />
          </div>
          {msgs.length === 1 && (
            <div className="row">{HINTS.map((h) => <button key={h} className="ghost chip" onClick={() => send(h)}>{h}</button>)}</div>
          )}
          <div className="row" style={{ flexWrap: 'nowrap' }}>
            <input style={{ flex: 1 }} value={text} onChange={(e) => setText(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && send()} placeholder="Ask about any item…" />
            <button onClick={() => send()} disabled={busy || !text.trim()}>Send</button>
          </div>
        </div>
      )}
    </>
  );
}
