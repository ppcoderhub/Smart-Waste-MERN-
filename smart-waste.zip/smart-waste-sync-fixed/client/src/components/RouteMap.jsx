import { useEffect, useRef } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

const num = (n, active, done) =>
  L.divIcon({ html: `<div class="stop ${active ? 'active' : ''} ${done ? 'done' : ''}">${n}</div>`, className: '', iconSize: [30, 30], iconAnchor: [15, 15] });

/** Numbered stops joined by the optimised route. Click a marker to select it. */
export default function RouteMap({ stops, start, activeId, onSelect }) {
  const el = useRef(null);
  const map = useRef(null);
  const layer = useRef(null);
  const cb = useRef(onSelect);
  cb.current = onSelect;

  useEffect(() => {
    map.current = L.map(el.current).setView([13.0827, 80.2707], 12);
    L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19, attribution: '© OpenStreetMap contributors' }).addTo(map.current);
    layer.current = L.layerGroup().addTo(map.current);
    return () => map.current.remove();
  }, []);

  useEffect(() => {
    layer.current.clearLayers();
    const pts = stops.map((s) => [s.location.lat, s.location.lng]);
    if (start) pts.unshift([start.lat, start.lng]);
    if (pts.length > 1) L.polyline(pts, { color: '#1f4d34', weight: 4, opacity: 0.8, dashArray: '8 8' }).addTo(layer.current);
    if (start) L.marker([start.lat, start.lng], { icon: L.divIcon({ html: '<div class="pin">🚛</div>', className: '', iconSize: [34, 34], iconAnchor: [17, 17] }) }).addTo(layer.current).bindTooltip('You are here');
    stops.forEach((s, i) => {
      L.marker([s.location.lat, s.location.lng], { icon: num(i + 1, s._id === activeId, s.status === 'scheduled') })
        .addTo(layer.current)
        .bindTooltip(`${s.address} · ${s.wasteType} · ${s.quantityKg} kg`)
        .on('click', () => cb.current(s._id));
    });
    if (pts.length) map.current.fitBounds(L.latLngBounds(pts), { padding: [40, 40], maxZoom: 16 });
    setTimeout(() => map.current.invalidateSize());
  }, [stops, start, activeId]);

  useEffect(() => {
    const s = stops.find((x) => x._id === activeId);
    if (s) map.current.panTo([s.location.lat, s.location.lng]);
  }, [activeId]);

  return <div ref={el} className="map" />;
}
