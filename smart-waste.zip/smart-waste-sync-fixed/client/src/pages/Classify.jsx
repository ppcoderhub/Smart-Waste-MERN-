import { useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import api, { errMsg } from '../api.js';
import { BIN, EMOJI, RECYCLABLE } from '../utils.js';

const QUICK = ['plastic bottle', 'banana peel', 'newspaper', 'glass jar', 'tin can', 'old phone', 'battery', 'paint'];
const load = () => { try { return JSON.parse(localStorage.getItem('scans') || '[]'); } catch { return []; } };

export default function Classify() {
  const nav = useNavigate();
  const [file, setFile] = useState(null);
  const [label, setLabel] = useState('');
  const [res, setRes] = useState(null);
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const [drag, setDrag] = useState(false);
  const [history, setHistory] = useState(load);
  const input = useRef(null);
  const preview = useMemo(() => (file ? URL.createObjectURL(file) : null), [file]);
  useEffect(() => () => preview && URL.revokeObjectURL(preview), [preview]);

  const pick = (f) => { if (f && f.type.startsWith('image/')) { setFile(f); setLabel(''); setRes(null); setErr(''); } else if (f) setErr('Please choose an image file.'); };

  const run = async (text = label) => {
    const fd = new FormData();
    if (file && !text) fd.append('image', file); else fd.append('label', text);
    setBusy(true); setErr('');
    try {
      const { data } = await api.post('/classify', fd);
      setRes(data);
      const entry = { item: data.item || text, category: data.category, at: Date.now() };
      const next = [entry, ...history.filter((h) => h.item !== entry.item)].slice(0, 8);
      setHistory(next); localStorage.setItem('scans', JSON.stringify(next));
    } catch (e) { setRes(null); setErr(errMsg(e)); }
    finally { setBusy(false); }
  };

  const quick = (q) => { setFile(null); setLabel(q); run(q); };

  return (
    <div className="split">
      <div className="card form">
        <h2>Sort my waste</h2>
        <div
          className={`drop ${drag ? 'over' : ''}`}
          onClick={() => input.current.click()}
          onDragOver={(e) => { e.preventDefault(); setDrag(true); }}
          onDragLeave={() => setDrag(false)}
          onDrop={(e) => { e.preventDefault(); setDrag(false); pick(e.dataTransfer.files[0]); }}
          role="button" tabIndex={0}
          onKeyDown={(e) => e.key === 'Enter' && input.current.click()}
        >
          {preview ? <img className="preview" src={preview} alt="Selected waste item" /> : <span>📷 Drop a photo here, or click to browse</span>}
          <input ref={input} type="file" accept="image/*" hidden onChange={(e) => pick(e.target.files[0])} />
        </div>
        {file && <button className="ghost" onClick={() => { setFile(null); setRes(null); }}>Remove photo</button>}
        <label>Or type the item
          <input placeholder="e.g. glass jar" value={label} onChange={(e) => setLabel(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && label && run()} />
        </label>
        <div className="row">{QUICK.map((q) => <button key={q} className="ghost chip" onClick={() => quick(q)}>{q}</button>)}</div>
        <button onClick={() => run()} disabled={busy || (!file && !label)}>{busy ? 'Identifying…' : 'Identify item'}</button>
        {err && <p className="err">{err}</p>}
      </div>

      <div>
        {res && (
          <div className={`card result ${RECYCLABLE.includes(res.category) ? 'ok' : 'warn'}`}>
            <div className="big-emoji">{EMOJI[res.category]}</div>
            <h3>{res.item || 'Item'}: {res.category}</h3>
            <p><span className="tag">{BIN[res.category]}</span> <span className={`tag ${res.recyclable ? 'collected' : ''}`}>{res.recyclable ? '♻️ Recyclable' : 'Not recyclable'}</span></p>
            <div className="meter" title={`${Math.round(res.confidence * 100)}% sure`}><div style={{ width: `${res.confidence * 100}%` }} /></div>
            <small>{Math.round(res.confidence * 100)}% sure{res.confidence < 0.5 ? ' · low confidence, try a clearer name or photo' : ''}</small>
            <p>{res.tip}</p>
            <button onClick={() => nav('/schedule', { state: { wasteType: res.category } })}>Schedule a pickup for this →</button>
          </div>
        )}
        {history.length > 0 && (
          <div className="card">
            <div className="row" style={{ justifyContent: 'space-between' }}>
              <h3>Recent scans</h3>
              <button className="ghost" onClick={() => { setHistory([]); localStorage.removeItem('scans'); }}>Clear</button>
            </div>
            <div className="row">
              {history.map((h) => <button key={h.at} className="ghost chip" onClick={() => quick(h.item)}>{EMOJI[h.category]} {h.item}</button>)}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
