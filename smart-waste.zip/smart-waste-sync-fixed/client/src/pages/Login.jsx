import { useState } from 'react';
import api, { errMsg } from '../api.js';
import { useToast } from '../toast.jsx';

export default function Login({ onAuth }) {
  const toast = useToast();
  const [mode, setMode] = useState('login');
  const [f, setF] = useState({ name: '', email: '', password: '', role: 'citizen' });
  const [err, setErr] = useState('');
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const submit = async () => {
    try {
      setErr('');
      const { data } = await api.post(`/auth/${mode}`, f);
      if (data.downgraded) toast('An admin already exists, so your account was created as a citizen.');
      onAuth(data);
    }
    catch (e) { setErr(errMsg(e)); }
  };
  return (
    <div className="hero">
      <div>
        <h1>Sort it right.<br />We'll pick it up.</h1>
        <p>Snap a photo to learn which bin an item belongs in, and book a doorstep collection for what's left.</p>
      </div>
      <div className="card auth">
        <h2>{mode === 'login' ? 'Log in' : 'Create account'}</h2>
        {mode === 'register' && <input placeholder="Full name" value={f.name} onChange={set('name')} />}
        <input placeholder="Email" type="email" value={f.email} onChange={set('email')} />
        <input placeholder="Password" type="password" value={f.password} onChange={set('password')} />
        {mode === 'register' && (
          <select value={f.role} onChange={set('role')}>
            <option value="citizen">Citizen</option><option value="collector">Collector</option><option value="admin">Admin (first account only)</option>
          </select>
        )}
        {err && <p className="err">{err}</p>}
        <button onClick={submit}>{mode === 'login' ? 'Log in' : 'Create account'}</button>
        <button className="ghost" onClick={() => setMode(mode === 'login' ? 'register' : 'login')}>
          {mode === 'login' ? 'New here? Create an account' : 'Have an account? Log in'}
        </button>
      </div>
    </div>
  );
}
