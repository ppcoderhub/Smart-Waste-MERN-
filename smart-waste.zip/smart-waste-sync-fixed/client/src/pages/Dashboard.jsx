import {useCallback,useEffect,useRef,useState} from 'react'; import {useNavigate} from 'react-router-dom'; import api from '../api.js'; import {useToast} from '../toast.jsx'; import {EMOJI,badgeFor,co2} from '../utils.js';
const FILTERS=['all','pending','scheduled','collected','completed','cancelled'];
export default function Dashboard(){
 const toast=useToast(),nav=useNavigate(),[list,setList]=useState(null),[me,setMe]=useState(null),[board,setBoard]=useState([]),[filter,setFilter]=useState('all'),[confirm,setConfirm]=useState(null),[syncing,setSyncing]=useState(false),[lastSync,setLastSync]=useState(null),prev=useRef(null);
 const refresh=useCallback(async(showMessage=false)=>{
   if(syncing) return;
   setSyncing(true);
   try {
     const results=await Promise.allSettled([api.get('/pickups'),api.get('/users/me'),api.get('/users/leaderboard')]);
     const [p,m,b]=results;
     if(p.status!=='fulfilled') throw p.reason;
     if(prev.current)p.value.data.forEach(x=>{const old=prev.current[x._id];if(old&&old!==x.status)toast(`Pickup update: ${x.wasteType} is now ${x.status}${x.status==='completed'?' 🎉':''}`,'ok')});
     prev.current=Object.fromEntries(p.value.data.map(x=>[x._id,x.status]));
     setList(p.value.data);
     if(m.status==='fulfilled') setMe(m.value.data);
     if(b.status==='fulfilled') setBoard(b.value.data);
     setLastSync(new Date());
     if(showMessage) toast(`Synced ${p.value.data.length} pickup${p.value.data.length===1?'':'s'} ✓`,'ok');
   } catch(e) {
     toast(e.response?.data?.message || 'Sync failed. Make sure the server is running.','err');
   } finally { setSyncing(false); }
 },[toast,syncing]);
 useEffect(()=>{refresh(false);const t=setInterval(()=>refresh(false),15000);return()=>clearInterval(t)},[refresh]);
 const cancel=async id=>{try{await api.patch(`/pickups/${id}/cancel`);toast('Pickup cancelled');setConfirm(null);refresh()}catch(e){toast(e.response?.data?.message||'Could not cancel','err')}};
 if(!list)return <div className="loading-screen"><div className="spinner"/>Loading your eco dashboard…</div>;
 const done=list.filter(p=>p.status==='completed'),kg=done.reduce((s,p)=>s+p.quantityKg,0),saved=done.reduce((s,p)=>s+co2(p.wasteType,p.quantityKg),0),badge=badgeFor(me?.points||0),shown=list.filter(p=>filter==='all'||p.status===filter);
 return <section><div className="dashboard-hero"><div><span className="eyebrow">WELCOME BACK, {me?.name?.split(' ')[0]?.toUpperCase()}</span><h1>Make every item <span>count.</span></h1><p>Sort smarter, book a pickup, and watch your environmental impact grow.</p><div className="row"><button onClick={()=>nav('/schedule')}>＋ Schedule pickup</button><button className="ghost" onClick={()=>nav('/classify')}>📷 Identify waste</button></div></div><div className="hero-orbit"><div className="orbit-ring">♻️<strong>{me?.points||0}</strong><small>eco points</small></div></div></div>
 <div className="grid stats-grid"><div className="stat-card"><span>♻️</span><small>DIVERTED</small><strong>{kg.toFixed(1)} kg</strong></div><div className="stat-card"><span>🌍</span><small>CO₂ AVOIDED</small><strong>{saved.toFixed(1)} kg</strong></div><div className="stat-card"><span>{badge.icon}</span><small>BADGE</small><strong>{badge.name}</strong></div><div className="stat-card"><span>📦</span><small>PICKUPS</small><strong>{list.length}</strong></div></div>
 <div className="section-head"><div><h2>Pickup activity</h2><p>Live updates refresh automatically every 15 seconds. New bookings start as <b>scheduled</b>.</p></div><button className="ghost" onClick={()=>refresh(true)} disabled={syncing}>{syncing?'↻ Syncing…':'↻ Sync now'}</button></div>
 {lastSync&&<small className="sync-time">Last synced: {lastSync.toLocaleTimeString()}</small>}<div className="filter-strip">{FILTERS.map(f=><button key={f} className={`ghost chip ${filter===f?'on':''}`} onClick={()=>setFilter(f)}>{f} <b>{f==='all'?list.length:list.filter(p=>p.status===f).length}</b></button>)}</div>
 {shown.length===0?<div className="empty card"><div>🌱</div><h3>No pickups here yet</h3><p>Start with a waste scan or schedule a collection.</p><button onClick={()=>nav('/schedule')}>Schedule now</button></div>:<div className="grid pickup-grid">{shown.map(p=><div className="card pickup-card" key={p._id}><div className="row between"><span className={`tag ${p.status}`}>{p.status}</span><span className="waste-icon">{EMOJI[p.wasteType]}</span></div><h3>{p.wasteType} <span>· {p.quantityKg} kg</span></h3><p>📍 {p.address}</p><small>Pickup: {new Date(p.date).toLocaleDateString()}</small>{p.status==='pending'&&(confirm===p._id?<div className="row actions"><button className="danger" onClick={()=>cancel(p._id)}>Yes, cancel</button><button className="ghost" onClick={()=>setConfirm(null)}>Keep</button></div>:<button className="ghost action-link" onClick={()=>setConfirm(p._id)}>Cancel pickup</button>)}</div>)}</div>}
 <section className="section"><div className="section-head"><h2>🏆 Community</h2><button className="ghost" onClick={()=>nav('/rewards')}>View rewards →</button></div><div className="card">{board.length?board.map((u,i)=><div className="lb" key={u._id}><span>{['🥇','🥈','🥉'][i]||`${i+1}.`} {u.name}</span><strong>{u.points} pts</strong></div>):<p>Be the first recycler!</p>}</div></section>
 </section>
}
