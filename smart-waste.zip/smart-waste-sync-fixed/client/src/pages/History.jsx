import { useEffect, useMemo, useState } from 'react';
import api from '../api.js';
import { EMOJI } from '../utils.js';

export default function History(){
  const [items,setItems]=useState([]);
  const [q,setQ]=useState('');
  const [filter,setFilter]=useState('all');
  const [loading,setLoading]=useState(true);
  const load=()=>api.get('/pickups').then(r=>setItems(r.data)).finally(()=>setLoading(false));
  useEffect(()=>{load(); const t=setInterval(load,15000); return()=>clearInterval(t)},[]);
  const shown=useMemo(()=>items.filter(p=>(filter==='all'||p.status===filter)&&(`${p.wasteType} ${p.address}`.toLowerCase().includes(q.toLowerCase()))),[items,q,filter]);
  return <section>
    <div className="page-head"><div><span className="eyebrow">ACTIVITY</span><h2>Pickup history</h2><p>Search, filter and track every request in one place.</p></div><button className="ghost" onClick={load}>↻ Refresh</button></div>
    <div className="toolbar card"><input value={q} onChange={e=>setQ(e.target.value)} placeholder="🔎 Search waste type or address..." />{['all','pending','scheduled','collected','completed','cancelled'].map(x=><button key={x} className={`ghost chip ${filter===x?'on':''}`} onClick={()=>setFilter(x)}>{x}</button>)}</div>
    {loading?<div className="skeleton card">Loading history…</div>:shown.length===0?<div className="empty card"><div>📭</div><h3>No matching pickups</h3><p>Try another filter or schedule a new pickup.</p></div>:
    <div className="timeline">{shown.map((p,i)=><div className="timeline-item" key={p._id}><div className="timeline-dot">{EMOJI[p.wasteType]}</div><div className="card timeline-card"><div className="row between"><span className={`tag ${p.status}`}>{p.status}</span><small>{new Date(p.createdAt||p.date).toLocaleString()}</small></div><h3>{p.wasteType} · {p.quantityKg} kg</h3><p>📍 {p.address}</p><small>Pickup date: {new Date(p.date).toLocaleDateString()}</small></div></div>)}</div>}
  </section>
}
