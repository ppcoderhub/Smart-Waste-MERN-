import { useEffect,useState } from 'react';
import api from '../api.js';
export default function Profile({user,onLogout}){
 const [me,setMe]=useState(user);
 const [theme,setTheme]=useState(localStorage.getItem('theme')||'system');
 useEffect(()=>{api.get('/users/me').then(r=>setMe({...user,...r.data}))},[]);
 const changeTheme=v=>{setTheme(v);if(v==='system'){localStorage.removeItem('theme');document.documentElement.removeAttribute('data-theme')}else{localStorage.setItem('theme',v);document.documentElement.setAttribute('data-theme',v)}};
 return <section><div className="page-head"><div><span className="eyebrow">ACCOUNT</span><h2>Your profile</h2><p>Manage your app preferences and account details.</p></div><div className="avatar">{(me.name||'U')[0].toUpperCase()}</div></div>
 <div className="split"><div className="card profile-card"><div className="avatar large">{(me.name||'U')[0].toUpperCase()}</div><h2>{me.name}</h2><p className="muted">{me.email||'Email hidden'}</p><span className="tag">{me.role}</span><div className="profile-stat"><strong>{me.points||0}</strong><span>Eco points · Rank #{me.rank||'—'}</span></div></div>
 <div className="card"><h3>Appearance</h3><p>Choose how Smart Waste looks on your device.</p><div className="theme-grid">{[['system','🖥️','System'],['light','☀️','Light'],['dark','🌙','Dark']].map(x=><button key={x[0]} className={`theme-btn ${theme===x[0]?'selected':''}`} onClick={()=>changeTheme(x[0])}><span>{x[1]}</span>{x[2]}</button>)}</div><hr/><h3>Session</h3><button className="danger" onClick={onLogout}>Log out securely</button></div></div>
 </section>
}
