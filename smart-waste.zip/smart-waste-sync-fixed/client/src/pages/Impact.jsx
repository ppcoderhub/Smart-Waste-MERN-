import { useEffect,useMemo,useState } from 'react';
import api from '../api.js';
import { co2,EMOJI } from '../utils.js';
export default function Impact(){
 const [items,setItems]=useState([]);
 useEffect(()=>{api.get('/pickups').then(r=>setItems(r.data))},[]);
 const done=items.filter(x=>x.status==='completed');
 const kg=done.reduce((s,x)=>s+x.quantityKg,0), saved=done.reduce((s,x)=>s+co2(x.wasteType,x.quantityKg),0);
 const by=useMemo(()=>{const m={};done.forEach(x=>m[x.wasteType]=(m[x.wasteType]||0)+x.quantityKg);return Object.entries(m).sort((a,b)=>b[1]-a[1])},[done]);
 const max=Math.max(1,...by.map(x=>x[1]));
 return <section><div className="page-head"><div><span className="eyebrow">IMPACT LAB</span><h2>Your environmental impact</h2><p>A simple view of what your completed pickups have diverted.</p></div><div className="pulse">● LIVE DATA</div></div>
 <div className="impact-hero card"><div><span className="eyebrow">TOTAL DIVERTED</span><p className="mega">{kg.toFixed(1)} kg</p><p>Waste collected through Smart Waste.</p></div><div className="impact-stat"><span>🌍</span><strong>{saved.toFixed(1)} kg</strong><small>estimated CO₂ avoided</small></div><div className="impact-stat"><span>🚛</span><strong>{done.length}</strong><small>completed pickups</small></div></div>
 <div className="split"><div className="card"><h3>Waste breakdown</h3>{by.length?by.map(([t,v])=><div className="bar-row" key={t}><span className="bar-label">{EMOJI[t]} {t}</span><div className="bar-track"><div style={{width:`${v/max*100}%`}}/></div><strong>{v.toFixed(1)} kg</strong></div>):<p>Complete a pickup to see your impact.</p>}</div>
 <div className="card"><h3>Quick facts</h3><div className="fact">♻️ <span>Every correctly sorted item makes downstream recycling easier.</span></div><div className="fact">💧 <span>Clean and dry recyclable containers before collection.</span></div><div className="fact">🔋 <span>Never put batteries or electronics in regular bins.</span></div></div></div>
 </section>
}
