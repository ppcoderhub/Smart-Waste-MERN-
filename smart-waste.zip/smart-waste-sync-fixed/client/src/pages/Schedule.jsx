import { useEffect, useRef, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import api, { errMsg } from '../api.js';
import MapPicker from '../components/MapPicker.jsx';
import { useToast } from '../toast.jsx';
import { TYPES, EMOJI, co2, pointsFor, isoDate } from '../utils.js';

const DATES = [['Tomorrow', 1], ['In 3 days', 3], ['Next week', 7]];

export default function Schedule() {
  const { state } = useLocation();
  const nav = useNavigate();
  const toast = useToast();
  const [f, setF] = useState({ wasteType: state?.wasteType || 'plastic', quantityKg: 2, address: '', date: isoDate(1) });
  const [pos, setPos] = useState(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const autoAddr = useRef(true); // only overwrite the address while the user hasn't typed their own
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  const choose = async (ll) => {
    const p = { lat: ll.lat, lng: ll.lng };
    setPos(p);
    if (!autoAddr.current) return;
    try { // free reverse geocoding; silently skipped if offline
      const r = await fetch(`https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${p.lat}&lon=${p.lng}`);
      const j = await r.json();
      if (j.display_name && autoAddr.current) setF((cur) => ({ ...cur, address: j.display_name }));
    } catch { /* ignore */ }
  };
  const locate = () => navigator.geolocation
    ? navigator.geolocation.getCurrentPosition((p) => choose({ lat: p.coords.latitude, lng: p.coords.longitude }), () => setErr('Location is blocked. Click the map instead.'))
    : setErr('This browser has no GPS. Click the map instead.');
  useEffect(() => { locate(); }, []);

  const kg = +f.quantityKg || 0;
  const submit = async () => {
    if (!pos) return setErr('Pick the pickup spot on the map first.');
    if (!f.address.trim()) return setErr('Please add an address or landmark.');
    setBusy(true); setErr('');
    try {
      await api.post('/pickups', { wasteType: f.wasteType, quantityKg: kg, address: f.address, date: f.date, location: pos });
      toast('Pickup scheduled ✅', 'ok');
      nav('/');
    } catch (e) { setErr(errMsg(e)); }
    finally { setBusy(false); }
  };

  return (
    <div className="split">
      <div className="card form">
        <h2>Schedule pickup</h2>
        <label>Waste type</label>
        <div className="row">
          {TYPES.map((t) => (
            <button key={t} className={`ghost chip ${f.wasteType === t ? 'on' : ''}`} onClick={() => setF({ ...f, wasteType: t })}>{EMOJI[t]} {t}</button>
          ))}
        </div>
        {['hazardous', 'e-waste'].includes(f.wasteType) && <p className="note">⚠️ Keep {f.wasteType} items sealed and separate from other waste.</p>}
        <label>Weight: {kg} kg
          <input type="range" min="0.5" max="50" step="0.5" value={kg} onChange={set('quantityKg')} />
        </label>
        <div className="impact">
          <span>🏅 +{pointsFor(f.wasteType, kg)} points</span>
          <span>🌍 ≈ {co2(f.wasteType, kg).toFixed(1)} kg CO₂ saved</span>
        </div>
        <label>Pickup date</label>
        <div className="row">
          {DATES.map(([l, d]) => <button key={l} className={`ghost chip ${f.date === isoDate(d) ? 'on' : ''}`} onClick={() => setF({ ...f, date: isoDate(d) })}>{l}</button>)}
        </div>
        <input type="date" min={isoDate(0)} value={f.date} onChange={set('date')} />
        <label>Address
          <input value={f.address} onChange={(e) => { autoAddr.current = false; set('address')(e); }} placeholder="Tap the map to fill this in" />
        </label>
        {err && <p className="err">{err}</p>}
        <button onClick={submit} disabled={busy}>{busy ? 'Scheduling…' : 'Schedule pickup'}</button>
      </div>
      <div className="card">
        <div className="row" style={{ justifyContent: 'space-between' }}>
          <h3>Where should we collect?</h3>
          <button className="ghost" onClick={locate}>📍 Use my location</button>
        </div>
        <p><small>{pos ? `Pin at ${pos.lat.toFixed(5)}, ${pos.lng.toFixed(5)}` : 'Click the map or drag the pin.'}</small></p>
        <MapPicker position={pos} onChange={choose} />
      </div>
    </div>
  );
}
