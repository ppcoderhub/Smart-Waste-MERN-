import { useEffect, useState } from 'react';
import api from '../api.js';
import { badgeFor, BADGES } from '../utils.js';

const challenges=[['♻️','Recycle 5 kg','Collect 5 kg of recyclable waste','+75'],['🌱','Go organic','Book an organic-waste pickup','+30'],['🗺️','Clean route','Complete a pickup without cancellation','+50']];
export default function Rewards(){
 const [me,setMe]=useState({points:0,rank:null}); const [board,setBoard]=useState([]);
 useEffect(()=>{Promise.all([api.get('/users/me'),api.get('/users/leaderboard')]).then(([a,b])=>{setMe(a.data);setBoard(b.data)})},[]);
 const b=badgeFor(me.points||0);
 return <section><div className="page-head"><div><span className="eyebrow">ECO REWARDS</span><h2>Rewards & challenges</h2><p>Turn responsible disposal into points and milestones.</p></div><div className="reward-orb">{b.icon}<span>{me.points||0}</span></div></div>
 <div className="grid"><div className="card reward-card"><span className="eyebrow">CURRENT BADGE</span><div className="badge-big">{b.icon}</div><h2>{b.name}</h2><div className="meter"><div style={{width:`${b.progress*100}%`}}/></div><small>{b.next?`${b.next.min-(me.points||0)} points to ${b.next.name}`:'Maximum badge reached!'}</small></div>
 <div className="card"><span className="eyebrow">YOUR RANK</span><p className="mega">#{me.rank||'—'}</p><p>Keep completing pickups to move up the community board.</p></div>
 <div className="card"><span className="eyebrow">LEVEL PATH</span>{BADGES.map(x=><div className="level-row" key={x.name}><span>{x.icon} {x.name}</span><strong>{x.min} pts</strong></div>)}</div></div>
 <h2 className="section-title">Weekly challenges</h2><div className="grid">{challenges.map(c=><div className="card challenge" key={c[1]}><div className="challenge-icon">{c[0]}</div><div><h3>{c[1]}</h3><p>{c[2]}</p><span className="tag">{c[3]} points</span></div></div>)}</div>
 <h2 className="section-title">Community leaderboard</h2><div className="card">{board.length?board.map((u,i)=><div className="lb" key={u._id}><span>{['🥇','🥈','🥉'][i]||`${i+1}.`} {u.name}</span><strong>{u.points} pts</strong></div>):<p>No points yet. Be the first recycler!</p>}</div>
 </section>
}
