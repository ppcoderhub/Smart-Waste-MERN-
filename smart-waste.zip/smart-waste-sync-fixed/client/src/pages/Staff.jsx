import { useCallback, useEffect, useMemo, useState } from 'react';
import api from '../api.js';
import RouteMap from '../components/RouteMap.jsx';
import { useToast } from '../toast.jsx';
import { EMOJI, co2, haversineKm } from '../utils.js';

const Bars = ({ rows, unit = '' }) => {
  const max = Math.max(1, ...rows.map((r) => r.value));
  return rows.map((r) => (
    <div className="bar-row" key={r.label}>
      <span className="bar-label">{r.label}</span>
      <div className="bar-track"><div style={{ width: `${(r.value / max) * 100}%` }} /></div>
      <span className="bar-val">{r.value}{unit}</span>
    </div>
  ));
};

export default function Staff({ role }) {
  const toast = useToast();
  const [route, setRoute] = useState([]);
  const [stats, setStats] = useState(null);
  const [start, setStart] = useState(null);
  const [fromMe, setFromMe] = useState(false);
  const [active, setActive] = useState(null);

  const load = useCallback(() => api.get('/pickups/route', { params: start || {} }).then((r) => setRoute(r.data)), [start]);
  useEffect(() => { load(); }, [load]);
  useEffect(() => { if (role === 'admin') api.get('/stats').then((r) => setStats(r.data)); }, [role]);

  const toggleStart = (on) => {
    setFromMe(on);
    if (!on) return setStart(null);
    navigator.geolocation?.getCurrentPosition(
      (p) => setStart({ lat: p.coords.latitude, lng: p.coords.longitude }),
      () => { setFromMe(false); toast('Location is blocked', 'err'); });
  };

  const mark = async (id, status) => {
    try {
      const { data } = await api.patch(`/pickups/${id}/status`, { status });
      toast(status === 'completed' ? `Pickup completed ✅${data.awarded ? ` (+${data.awarded} pts to ${data.user?.name})` : ''}` : status === 'collected' ? 'Pickup collected 📦' : 'Pickup accepted 📅');
      load();
    } catch (e) { toast(e.response?.data?.message || 'Update failed', 'err'); }
  };

  // Leg distances along the optimised order, plus the total
  const { legs, total } = useMemo(() => {
    const pts = route.map((p) => p.location);
    if (start) pts.unshift(start);
    const legs = route.map((_, i) => { const from = start ? pts[i] : pts[i - 1]; return from ? haversineKm(from, route[i].location) : 0; });
    return { legs, total: legs.reduce((a, b) => a + b, 0) };
  }, [route, start]);

  const co2Total = stats ? stats.byType.reduce((s, t) => s + co2(t._id, t.kg), 0) : 0;
  const days = stats ? [...Array(7)].map((_, i) => { const d = new Date(Date.now() - (6 - i) * 864e5).toISOString().slice(0, 10); return { label: d.slice(5), value: stats.daily.find((x) => x._id === d)?.count || 0 }; }) : [];

  return (
    <>
      {stats && (
        <section>
          <h2>Waste collected by type</h2>
          <div className="grid">
            {stats.byType.map((t) => <div className="card" key={t._id}><h3>{EMOJI[t._id]} {t._id}</h3><p className="big">{t.kg.toFixed(1)} kg</p><small>{t.count} pickups</small></div>)}
            <div className="card"><h3>🌍 CO₂ saved (est.)</h3><p className="big">{co2Total.toFixed(1)} kg</p></div>
          </div>
          <div className="split" style={{ margin: '1rem 0' }}>
            <div className="card"><h3>Pickups by status</h3><Bars rows={stats.byStatus.map((s) => ({ label: s._id, value: s.count }))} /></div>
            <div className="card"><h3>Booked in the last 7 days</h3><Bars rows={days} /></div>
          </div>
        </section>
      )}

      <div className="row" style={{ justifyContent: 'space-between' }}>
        <div><h2>Optimised route ({route.length} stops · {total.toFixed(1)} km)</h2><small>Workflow: Scheduled → Collected → Completed</small></div>
        <label className="row" style={{ flexDirection: 'row', fontWeight: 500 }}>
          <input type="checkbox" checked={fromMe} onChange={(e) => toggleStart(e.target.checked)} /> Start from my location
        </label>
      </div>
      {route.length === 0 && <p>No pending pickups. Completed pickups will remain visible in the list.</p>}
      {route.length > 0 && <div className="card"><RouteMap stops={route} start={start} activeId={active} onSelect={setActive} /></div>}
      <ol className="route">
        {route.map((p, i) => (
          <li className={`card ${active === p._id ? 'active' : ''}`} key={p._id} onClick={() => setActive(p._id)}>
            <div>
              <strong>{p.address}</strong><br />
              <small>{p.user?.name} · {EMOJI[p.wasteType]} {p.wasteType} · {p.quantityKg} kg{i > 0 || start ? ` · +${legs[i].toFixed(1)} km` : ''}</small>
            </div>
            <div className="row" onClick={(e) => e.stopPropagation()}>
              <a className="ghost btnlink" target="_blank" rel="noopener noreferrer" href={`https://www.google.com/maps/dir/?api=1&destination=${p.location.lat},${p.location.lng}`}>🧭 Navigate</a>
              {p.status === 'pending' && <button className="ghost" onClick={() => mark(p._id, 'scheduled')}>Accept</button>}
              {p.status === 'scheduled' && <button onClick={() => mark(p._id, 'collected')}>Mark collected</button>}
              {p.status === 'collected' && <button onClick={() => mark(p._id, 'completed')}>Mark completed</button>}
              {p.status === 'completed' && <span className="tag completed">✅ Completed</span>}
            </div>
          </li>
        ))}
      </ol>
    </>
  );
}
