// Rough kg CO2e avoided per kg of waste diverted from landfill (indicative averages, for motivation only).
export const CO2_PER_KG = { plastic: 1.5, paper: 1.0, glass: 0.3, metal: 4.0, organic: 0.5, 'e-waste': 2.0, hazardous: 0, general: 0 };
export const RECYCLABLE = ['organic', 'plastic', 'paper', 'glass', 'metal', 'e-waste'];
export const TYPES = ['organic', 'plastic', 'paper', 'glass', 'metal', 'e-waste', 'hazardous', 'general'];
export const EMOJI = { organic: '🍌', plastic: '🧴', paper: '📰', glass: '🫙', metal: '🥫', 'e-waste': '🔋', hazardous: '☣️', general: '🗑️' };
export const BIN = { organic: 'Green bin', plastic: 'Blue bin', paper: 'Blue bin', glass: 'Blue bin', metal: 'Blue bin', 'e-waste': 'E-waste point', hazardous: 'Hazardous pickup', general: 'Black bin' };

export const co2 = (type, kg) => (CO2_PER_KG[type] || 0) * kg;
export const pointsFor = (type, kg) => Math.max(1, Math.round(kg * (RECYCLABLE.includes(type) ? 15 : 5)));

export const BADGES = [
  { min: 0, name: 'Seedling', icon: '🌱' },
  { min: 50, name: 'Sorter', icon: '♻️' },
  { min: 200, name: 'Recycler', icon: '🌿' },
  { min: 500, name: 'Eco Hero', icon: '🌍' },
];
export function badgeFor(points) {
  const idx = BADGES.reduce((acc, b, i) => (points >= b.min ? i : acc), 0);
  const next = BADGES[idx + 1];
  return { ...BADGES[idx], next, progress: next ? (points - BADGES[idx].min) / (next.min - BADGES[idx].min) : 1 };
}

export function haversineKm(a, b) {
  const rad = (d) => (d * Math.PI) / 180;
  const h = Math.sin(rad(b.lat - a.lat) / 2) ** 2 + Math.cos(rad(a.lat)) * Math.cos(rad(b.lat)) * Math.sin(rad(b.lng - a.lng) / 2) ** 2;
  return 2 * 6371 * Math.asin(Math.sqrt(h));
}

export const isoDate = (offsetDays = 0) => {
  const d = new Date();
  d.setDate(d.getDate() + offsetDays);
  return d.toISOString().slice(0, 10);
};
